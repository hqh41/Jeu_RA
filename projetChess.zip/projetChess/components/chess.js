arcs_module(function(ARCS,three,_fontloader) {

    var Chess;

    Chess = ARCS.Component.create(
        function() {
            var granary,resultA,resultB,currentPlayer,currentPlace,circleSelect,circleNum, ifselected,canP,isPlayerA;
            var id=-1;
            var self=this;
            var objRoot;
            var sphere=[];
            var myChess = [];
            var granary=[0,1,2,3,4,5,6,7,
                8,9,10,11,12,13,14,15,
                -1,-1,-1,-1,-1,-1,-1,-1,
                -1,-1,-1,-1,-1,-1,-1,-1,
                -1,-1,-1,-1,-1,-1,-1,-1,
                -1,-1,-1,-1,-1,-1,-1,-1,
                16,17,18,19,20,21,22,23,
                24,25,26,27,28,29,30,31];
        
        
            
            for(i =0;i < 32;i++) {
                myChess[i]= {
                    positionx : 0,
                     positiony : 0,
                     type : 0
                  };

                var white;
                if(i<16) {
                    white = 1;
                } 
                else {
                    white = -1;
                }
                

                //myChess[i] = myChesstype;
                if((i == 0) || (i == 7) || (i == 24) || (i == 31)) {
                    myChess[i].type = 4*white;
                    
                }
                else if((i == 1) || (i == 6) || (i == 25) || (i == 30)) {
                   myChess[i].type = 2*white;
                }
                else if((i == 2) || (i == 5) || (i == 26) || (i == 29)) {
                    myChess[i].type = 3*white;
                }
                else if((i == 3) || (i == 27)) {
                    myChess[i].type = 5*white;
                }
                else if((i == 4) ||(i == 28)) {
                    myChess[i].type = 6*white;
                }
                else {
                    myChess[i].type = white;
                }
                if(i < 16) {
                     myChess[i].positionx = parseInt(i/8);
                     myChess[i].positiony = parseInt(i%8);
                } 
                else {
                      myChess[i].positionx = parseInt(i/8)+4;
                      myChess[i].positiony = parseInt(i%8);
                }  

            }
            myChess[32]= {
                positionx : 0,
                 positiony : 0,
                 type : 0
              };
              myChess[33]= {
                positionx : 0,
                 positiony : 0,
                 type : 0
              };
            myChess[32].type="circle";
            myChess[32].positionx=0;
            myChess[32].positiony=0;
            myChess[33].type="select";
            myChess[33].positionx=0;
            myChess[33].positiony=0;

            for(var i=0; i<34; i++){
                console.log("mychess[" +i+"]"+"="+myChess[i].type+"/"+myChess[i].positionx+"/"+myChess[i].positiony);
            }


          
    this.setObject1 = function (obj) {
                objRoot = new THREE.Object3D();
                obj.parent.add(objRoot);
                obj.parent.remove(obj);
                objRoot.add(obj);


                var box = new THREE.Box3;
                box.setFromObject(obj);
                var s = box.size();
                var scale = MAX3(s.x, s.y, s.z);
                console.log(scale);
                obj.add(new THREE.AxisHelper(scale / 2));

                console.log("create sphere");
                console.log("!!",granary)
                for (var i=0;i<32;i++){
                    if(myChess[i].type < 0)
                    {
                        sphere[i]=objRoot.clone();
                        self.emit("newObject1",sphere[i]);
                    }
                }
                self.emit("object1Set");
            
          

            };
            this.setObject2 = function (obj) {  //bai
                objRoot = new THREE.Object3D();
                obj.parent.add(objRoot);
                obj.parent.remove(obj);
                objRoot.add(obj);

                var box = new THREE.Box3;
                box.setFromObject(obj);
                var s = box.size();
                var scale = MAX3(s.x, s.y, s.z);
                console.log(scale);
                obj.add(new THREE.AxisHelper(scale / 2));

                console.log("create sphere");
                for (var i=0;i<32;i++){
                    if(myChess[i].type>0)
                    {
                        sphere[i]=objRoot.clone();
                        self.emit("newObject2",sphere[i]);
                    }
                }
                //console.log(sphere)
                self.emit("object2Set");          
            };

            this.setCircle = function (obj) {  
                objRoot = new THREE.Object3D();
                obj.parent.add(objRoot);
                obj.parent.remove(obj);
                objRoot.add(obj);
                
                var box = new THREE.Box3;
                box.setFromObject(obj);
                var s = box.size();
                var scale = MAX3(s.x, s.y, s.z);
                console.log(scale);
                obj.add(new THREE.AxisHelper(scale / 2));

                console.log("create circle");
                    sphere[32]=objRoot.clone();
                    self.emit("newCircle",sphere[32]);
                //console.log(sphere)
                self.emit("circleSet");          
            };

            this.setSelect = function (obj) {  
                objRoot = new THREE.Object3D();
                obj.parent.add(objRoot);
                obj.parent.remove(obj);
                objRoot.add(obj);
                
                var box = new THREE.Box3;
                box.setFromObject(obj);
                var s = box.size();
                var scale = MAX3(s.x, s.y, s.z);
                console.log(scale);
                obj.add(new THREE.AxisHelper(scale / 2));

                console.log("create select");
                    sphere[33]=objRoot.clone();
                    self.emit("newSelect",sphere[33]);
                //console.log(sphere)
                self.emit("selectSet");          
            };


           



            var MAX3 = function (a,b,c) {
                if ( a >= b ) {
                   if ( a >= c) {
                       return a;
                   } else {
                       return c;
                   }
               } else {
                   if (b >= c) {
                       return b;
                   } else {
                       return c;
                   }
               }
           };



           





           this.setSphere=function(markers){
            console.log("setSphere!!!");
            //console.log("当前位置：" +circleNum);
            if (sphere[0] === undefined) { 
                console.log("sphere[0] undefined");
                return ; 
            }
            var i ;
            var j ;
            var k,k1 ;
            var sum ;

            

            for ( i = 0; i < markers.length; i++) {
                //console.log("mychess[" +i+"]"+"="+myChess[i].type+"/"+myChess[i].positionx+"/"+myChess[i].positiony);
                if ( markers[i].id === id ) {
                    var pos=markers[i].pose.position;
                    var rot=markers[i].pose.rotation;
                    var mat=new THREE.Matrix4();
                    mat.set(rot[0][0],rot[0][1],rot[0][2],pos[0],
                        rot[1][0],rot[1][1],rot[1][2],pos[1],
                        rot[2][0],rot[2][1],rot[2][2],pos[2],
                        0,        0,        0,        1);

                        //initialisation of seeds
                        //console.log(granary);

                        sphere[32].position.x=pos[0]+0.01-0.07+((myChess[32].positionx)+1)*0.012;
                        sphere[32].position.y=pos[1]+0.05-((myChess[32].positiony) +1)*0.014+0.002;
                        sphere[32].position.z=pos[2]+0.02;

                        sphere[33].position.x=pos[0]+0.01-0.07+((myChess[33].positionx)+1)*0.012;
                        sphere[33].position.y=pos[1]+0.05-((myChess[33].positiony) +1)*0.014+0.002;
                        sphere[33].position.z=pos[2]+0.015
                        
                        for(j = 0; j < 32; j++){
                            //console.log("myChess"+j+"type = " +myChess[j].type+ "x="+myChess[j].positionx+"y="+myChess[j].positiony);
                            if(myChess[j].type != 0) {
                            
                                //k = (j%8) +1;
                                //k1 = parseInt((j-k+1)/8) +1; 

                                k = (myChess[j].positiony) +1;
                                k1 = (myChess[j].positionx)+1;
                                var ins  = 8*(myChess[j].positionx) + myChess[j].positiony;
                                //console.log("TYPE = " +myChess[j].type);

                                //console.log("k = "+k+" k1 = "+ k1+" j = "+j);
                                if( (ins%8==0) ){
                                        sphere[j].position.x=pos[0]+0.01-0.07+k1*0.012;
                                        sphere[j].position.y=pos[1]+0.05-k*0.014+0.002;
                                        sphere[j].position.z=pos[2]+0.02;
                                        sphere[j].rotation.setFromRotationMatrix(mat);
                                        //console.log("sphere["+j+"]"+"k = "+k + "positiony" + myChess[j].positiony);
                                }
                                else if(ins%8==1){
                                     sphere[j].position.x=pos[0]+0.01-0.07+k1*0.012;
                                        sphere[j].position.y=pos[1]+0.05-k*0.014+0.002;
                                    sphere[j].position.z=pos[2]+0.02;
                                    sphere[j].rotation.setFromRotationMatrix(mat);
                                    //console.log("sphere["+j+"]"+"k = "+k);
                                }
                                
                                else if(ins%8==2){
                                     sphere[j].position.x=pos[0]+0.01-0.07+k1*0.012;
                                        sphere[j].position.y=pos[1]+0.05-k*0.014+0.002;
                                    sphere[j].position.z=pos[2]+0.02;
                                    sphere[j].rotation.setFromRotationMatrix(mat);
                                   //console.log("sphere["+j+"]"+"k = "+k);
                                }
                                else if(ins%8==3){
                                     sphere[j].position.x=pos[0]+0.01-0.07+k1*0.012;
                                        sphere[j].position.y=pos[1]+0.05-k*0.014+0.002;
                                    sphere[j].position.z=pos[2]+0.02;
                                    sphere[j].rotation.setFromRotationMatrix(mat);
                                    //console.log("sphere["+j+"]"+"k = "+k);
                                }

                                else if(ins%8==4){
                                      sphere[j].position.x=pos[0]+0.01-0.07+k1*0.012;
                                        sphere[j].position.y=pos[1]+0.05-k*0.014+0.002;
                                    sphere[j].position.z=pos[2]+0.02;
                                    sphere[j].rotation.setFromRotationMatrix(mat);
                                    //console.log("sphere["+j+"]"+"k = "+k);
                                }
                                else if(ins%8==5){
                                   sphere[j].position.x=pos[0]+0.01-0.07+k1*0.012;
                                        sphere[j].position.y=pos[1]+0.05-k*0.014+0.002;
                                    sphere[j].position.z=pos[2]+0.02;
                                    sphere[j].rotation.setFromRotationMatrix(mat);
                                    //console.log("sphere["+j+"]"+"k = "+k);
                                }
                                else if(ins%8==6){
                                sphere[j].position.x=pos[0]+0.01-0.07+k1*0.012;
                                        sphere[j].position.y=pos[1]+0.05-k*0.014+0.002;
                                    sphere[j].position.z=pos[2]+0.02;
                                    sphere[j].rotation.setFromRotationMatrix(mat);
                                   //console.log("sphere["+j+"]"+"k = "+k);
                                }
                                else if(ins%8==7){
                              sphere[j].position.x=pos[0]+0.01-0.07+k1*0.012;
                                        sphere[j].position.y=pos[1]+0.05-k*0.014+0.002;
                                    sphere[j].position.z=pos[2]+0.02;
                                    sphere[j].rotation.setFromRotationMatrix(mat);
                                   //console.log("sphere["+j+"]"+"k = "+k);
                                }  

                            }  
                            
                    
                            }       
                        }

                   }            
            }



            //initialize gameboard 
            this.init=function(){   
                console.log("in init");     
                //granary 这里重新定义为棋子的类型 一共六种棋子 王(6)，后(5)，车(4)，象(3)，马(2)，兵(1)
                /*granary=[4,2,3,5,6,3,2,4,
                    1,1,1,1,1,1,1,1,
                    0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,
                    -1,-1,-1,-1,-1,-1,-1,-1,
                    -4,-2,-3,-5,-6,-3,-2,-4];*/
            
                //the winnings of A
                resultA=0;
                //the winnings of B
                resultB=0;
                //current player
                currentPlayer="A";

                //用于选择棋子的红圈起始位置,并且定义初始circlenum圈住0
                if(sphere[0]!==undefined)
                    currentPlace = sphere[0].position;
                circleNum = 0;
                //self.emit("circleNumber",circleNum);
                ifselected = -1;

                canP = false;
                isPlayerA = 1;
   
                //setup object position
                //setSphere(markers);
                
            }

             //num为被选中的棋子号
            //  this.setCircle = function(num) {
            //     if(num<0||num>32){
            //         //check if num is valid
            //         console.log("It's not a correct chessNumber");
            //         return;
            //     }
            //     circleSelect = createArc(sphere[num].position.x,sphere[num].position.y);
            //     console.log("drawSelectedCircle!"+ num);

            //     self.emit("circleSelected",circleSelect); 
            // }
            
            //用于画选中的圆圈
           function createArc(x,y){
                 let geometry = new THREE.CircleGeometry(x,y,0,360/180*Math.PI);
                 let material = new THREE.LineBasicMaterial({color:0xffffff});
                 let arc = new THREE.Line(geometry,material);
                 return arc;
            };

            var check =  function (selectNum, changeNum){
                var remain0 = selectNum % 8;
                var res0 = parseInt((selectNum-remain0)/8);
                var remain1 = changeNum % 8;
                var res1 = parseInt((changeNum-remain1)/8);
                return Math.abs(res1 - res0);
            };
//王(6)，后(5)，车(4)，象(3)，马(2)，兵(1)
            var whichChess = function(chessNum){
                
                if(chessNum==1*isPlayerA){
                    return ' pion';
                }
                else if(chessNum == 2*isPlayerA){
                    return ' cavalier';
                }
                else if(chessNum == 3*isPlayerA){
                    return ' fou';
                }
                else if(chessNum == 4*isPlayerA){
                    return ' tour';
                }
                else if(chessNum == 5*isPlayerA){
                    return ' dame';
                }
                else if(chessNum == 6*isPlayerA){
                    return ' roi';
                }
                else{
                    return ' and il y a ien';
                }           
            }


            //update the array granary after selection num
            this.update=function(num){
                //var circlenum = circleNumber;
                //console.log("in update" + num);
                if(num<0||num>5){
                    //check if num is valid
                    console.log("It's not a correct keycode");
                    return;
                }
                
                if(num == 0 || num == 1 || num == 2 || num == 3){
                    switch(num){
                        //向上-1，不小于0
                            case 0: 
                                if(circleNum -1 < 0) {
                                    circleNum = 0;
                                }
                                else{
                                    circleNum = circleNum - 1;
                                }
                                break;
                        //向下+1，不能大于63
                            case 1: 
                                if(circleNum +1 > 63) {
                                    circleNum = 63;
                                }
                                else{
                                    circleNum = circleNum + 1;
                                }
                                break;
                        //向左-8，不能小于0
                            case 2: 
                                if(circleNum -8 < 0) {
                                }
                                else{
                                    circleNum = circleNum - 8;
                                }
                                break;
                        //向右+8，不能大于63
                            case 3: 
                                if(circleNum +8 > 63) {
                                }
                                else{
                                    circleNum = circleNum + 8;
                                }
                                break; 
    
                    }    
                    console.log("---------"+circleNum)
                    myChess[32].positionx = ((circleNum+1)-(circleNum+1)%8)/8;
                    myChess[32].positiony = (circleNum+1)%8 -1;
                    if(granary[circleNum]!= -1){
                    console.log("你现在在"+ circleNum + "这里有"+ whichChess(myChess[granary[circleNum]].type));  
                    document.getElementById("info").innerHTML="Vous êtes maintenant dans " + circleNum;  
                    }
                    else{
                        console.log("你现在在"+ circleNum + "啥都没有");
                        document.getElementById("info").innerHTML="Vous êtes maintenant dans " + circleNum + " and il y a rien";
                    }            
                }
                //ifselected是当前选中棋子的位置，若未选中则为-1
                if(ifselected != -1){
                    console.log(granary);
                    console.log("现在你已经选中棋子了");
                    document.getElementById("info").innerHTML="Maintenant vous avez choisi une pièce";
                    console.log("你现在是"+isPlayerA);
                    document.getElementById("info").innerHTML="Vous êtes maintenant " + isPlayerA;
                    var checkLine = check(ifselected, circleNum);
                    
                    switch(myChess[granary[ifselected]].type){
                        //兵逻辑：不吃的话只能向前，否则可以吃斜前方的棋子
                        case 1*isPlayerA:
                        console.log("你选择的是小兵");
                        document.getElementById("info").innerHTML="Vous avez choisi le pion";
                        //如果兵还没出城，则可以向前走一步或两步
                        if((ifselected >= 8 && ifselected <= 15) || (ifselected>=48 && ifselected<=55)){
                            //如果所选位置没有别的棋子
                            if(granary[circleNum] == -1){
                                if((circleNum == ifselected + 8*isPlayerA)|| (circleNum == ifselected + 16*isPlayerA)){
                                    
                                    canP = true;
                                    console.log("你现在是一个还没出门的兵，所选位置没有别的棋子，可以落子");
                                    document.getElementById("info").innerHTML="Vous êtes pion, vous pouvez se mettre ici";
                                }
                                else{
                                    canP = false;
                                    console.log("你现在是一个还没出门的兵，所选位置没有别的棋子，buuuuuuu可以落子");
                                    document.getElementById("info").innerHTML="Vous êtes pion, vous ne pouvez pas se mettre ici";
                                }
                            }
                            else if(myChess[granary[circleNum]].type*isPlayerA > 0)
                            {
                                canP = false;
                                console.log("你现在是一个还没出门的兵，所选位置有自己人，buuuuuuu可以落子");
                                document.getElementById("info").innerHTML="Vous êtes pion, vous ne pouvez pas se mettre ici";
                            } 
                            else{
                                if((circleNum == ifselected + 7*isPlayerA)|| (circleNum == ifselected + 9*isPlayerA)){
                                    if(checkLine == 1){
                                        canP = true;
                                        console.log("你现在是一个还没出门的兵，所选位置有敌人，可以吃子");
                                        document.getElementById("info").innerHTML="Vous êtes pion, vous pouvez se mettre ici et manger l'ennemi";
                                    }
                                    else{
                                        canP = false;
                                        console.log("你现在是一个还没出门的兵，所选位置有敌人，buuuuuuuu可以吃子");
                                        document.getElementById("info").innerHTML="Vous êtes pion, vous ne pouvez pas se mettre ici";
                                    }
                                }
                                else{
                                    canP = false;
                                    console.log("你现在是一个还没出门的兵，所选位置有敌人，buuuuuuuu可以吃子");
                                    document.getElementById("info").innerHTML="Vous êtes pion, vous ne pouvez pas se mettre ici";
                                }
                            }
                        }
                        //兵已经出城了
                        else{
                            if(granary[circleNum] == -1){
                                if(circleNum == ifselected + 8*isPlayerA){
                                    canP = true;
                                    console.log("兵已出门，所选位置没有别的棋子，可以落子");
                                    document.getElementById("info").innerHTML="Vous êtes pion, vous pouvez se mettre ici";
                                }
                                else{
                                    canP = false;
                                    console.log("兵已出门，所选位置没有别的棋子，buuuuuuu可以落子");
                                    document.getElementById("info").innerHTML="Vous êtes pion, vous ne pouvez pas se mettre ici";
                                }
                            }
                            else if(myChess[granary[circleNum]].type*isPlayerA > 0)
                            {
                                canP = false;
                                console.log("兵已出门，所选位置有自己人，buuuuuuu可以落子");
                                document.getElementById("info").innerHTML="Vous êtes pion, vous ne pouvez pas se mettre ici";
                            } 
                            else{
                                if((circleNum == ifselected + 7*isPlayerA) || (circleNum == ifselected + 9*isPlayerA)){
                                    if(checkLine == 1){
                                        canP = true;
                                        console.log("兵已出门，所选位置有敌人，可以吃子");
                                        document.getElementById("info").innerHTML="Vous êtes pion, vous pouvez se mettre ici et manger l'ennemi";
                                    }
                                    else{
                                        canP = false;
                                        console.log("兵已出门，所选位置没有别的棋子，buuuuuuu可以落子");
                                        document.getElementById("info").innerHTML="Vous êtes pion, vous ne pouvez pas se mettre ici";
                                    }
                                }
                                else{
                                    canP = false;
                                    console.log("兵已出门，所选位置有敌人，buuuuuuuu可以吃子");
                                    document.getElementById("info").innerHTML="Vous êtes pion, vous ne pouvez pas se mettre ici";
                                }
                            }
                        }
                        break;
                        /*马 
                        *即先沿横线或直线走一格，
                        *然后沿斜线离原格方向一格，
                        *在走第一格时即使该格已有棋子占据也仍可行走，
                        *在走第二格时有棋子，则能吃掉该棋子。*/
                        case 2*isPlayerA:
                        
                        if(((granary[circleNum] != -1) && (myChess[granary[circleNum]].type*isPlayerA < 0)) || (granary[circleNum]==-1)){
                            if((circleNum == ifselected-10) 
                            ||   (circleNum == ifselected-6) 
                            || (circleNum == ifselected+10) 
                            ||  (circleNum == ifselected+6))
                            {
                                if(checkLine == 1){
                                    canP = true;
                                    console.log("马所选位置有敌人或空，允许落子");
                                    document.getElementById("info").innerHTML="Vous êtes cavalier, vous pouvez se mettre ici";
                                }
                                else{
                                    canP = false;
                                    console.log("马所选位置有敌人或空，buuuuuuuu允许落子");
                                    document.getElementById("info").innerHTML="Vous êtes cavalier, vous ne pouvez pas se mettre ici";
                                }

                            }
                            else if((circleNum == ifselected-17) 
                            ||(circleNum == ifselected-15) 
                            ||(circleNum == ifselected+17) 
                            ||(circleNum == ifselected+15)){
                                if(checkLine == 2){
                                    canP = true;
                                    console.log("马所选位置有敌人或空，允许落子");
                                    document.getElementById("info").innerHTML="Vous êtes cavalier, vous pouvez se mettre ici";
                                }
                                else{
                                    canP = false;
                                    console.log("马所选位置有敌人或空，buuuuuuuu允许落子, checkLine ="+checkLine);
                                    document.getElementById("info").innerHTML="Vous êtes cavalier, vous ne pouvez pas se mettre ici";
                                }
                            }
                            else{
                                canP = false;
                                console.log("马所选位置有敌人或空，buuuuuuuu允许落子");
                                document.getElementById("info").innerHTML="Vous êtes cavalier, vous ne pouvez pas se mettre ici";
                            }
                        }
                        else{
                            canP = false;
                            console.log("马所选位置有自己人，buuuuuuuu允许落子");
                            document.getElementById("info").innerHTML="Vous êtes cavalier, vous ne pouvez pas se mettre ici";
                        }
                        break;

                        
                        //象逻辑：只可以斜着走，但不可以转向或者越过其他棋子
                        case 3*isPlayerA:
                        var i,j;
                        var flag = 0;
                        for(i = 1;i < 8 ;i++) {
                            if((circleNum == ifselected + 9*i) && (checkLine == i)) {
                            	if((granary[ifselected + 9*j] != -1)){
                                for(j = 1;j <= i ;j++) {
                                    if(myChess[granary[ifselected + 9*j]].type*isPlayerA > 0) {
                                        flag = -1;
                                        console.log("象所在+位置期间有己方，buuuuuuuu允许落子");
                                        document.getElementById("info").innerHTML="Vous êtes fou, vous ne pouvez pas se mettre ici";
                                        break;
                                    }
                                }
                                }
                                if(flag == -1) {
                                    canP = false;
                                } else {
                                    canP = true;
                                }
                                break;
                            } 
                            else if((circleNum == ifselected - 9*i)&& (checkLine == i)) {
                                for(j = 1;j <= i ;j++) {
                                	if((granary[ifselected - 9*j] != -1)){
                                    if(myChess[granary[ifselected - 9*j]].type*isPlayerA > 0) {
                                        flag = -1;
                                        console.log("象所在-位置期间有己方，buuuuuuuu允许落子");
                                        document.getElementById("info").innerHTML="Vous êtes fou, vous ne pouvez pas se mettre ici";
                                    }
                                }
                            }
                                if(flag == -1) {
                                    canP = false;
                                } else {
                                    canP = true;
                                }
                                break;
                            }
                        
                            else if((circleNum == ifselected + 7*i)&& (checkLine == i)) {
                                for(j = 1;j <= i ;j++) {
                                	if((granary[ifselected + 7*j] != -1)){
                                    if(myChess[granary[ifselected + 7*j]].type*isPlayerA > 0) {
                                        flag = -1;
                                        console.log("象所在+位置期间有己方，buuuuuuuu允许落子");
                                        document.getElementById("info").innerHTML="Vous êtes fou, vous ne pouvez pas se mettre ici";
                                    }
                                }
                                }
                                if(flag == -1) {
                                    canP = false;
                                } else {
                                    canP = true;
                                }
                                break;
                            } 
                            else if((circleNum == ifselected - 7*i)&& (checkLine == i)) {
                                for(j = 1;j <= i ;j++) {
                                	if((granary[ifselected - 7*j] != -1)){
                                    if(myChess[granary[ifselected - 7*j]].type*isPlayerA > 0) {
                                        flag = -1;
                                        console.log("象所在-位置期间有己方，buuuuuuuu允许落子");
                                        document.getElementById("info").innerHTML="Vous êtes fou, vous ne pouvez pas se mettre ici";
                                    }
                                }
                                }
                                if(flag == -1) {
                                    canP = false;
                                } else {
                                    canP = true;
                                }
                                break;
                            }
                            else {
                                canP = false;
                            } 
                        }

                        break;
                        /*城堡/车（Rook）的走法是横走或直走，格数不限，但不可斜走或越过其他棋子。其吃子与走法相同 */
                        case 4*isPlayerA:
                        var i = 0, j = 0;
                        var flag = 0;
                        for(i = 1;i < 8 ;i++) {
                                if((circleNum == ifselected + 8*i)) {
                                    for(j = 1;j <= i ;j++) {
                                    	if((granary[ifselected + 8*j] != -1)){
                                        if(myChess[granary[ifselected + 8*j]].type*isPlayerA > 0) {
                                            flag = -1;
                                            console.log("车所在横+位置期间有己方，buuuuuuuu允许落子");
                                            document.getElementById("info").innerHTML="Vous êtes tour, vous ne pouvez pas se mettre ici";
                                        }
                                    }
                                    }
                                    if(flag == -1) {
                                    canP = false;
                                    } else {
                                    canP = true;
                                    }
                                    break;
                                } 
                                else if((circleNum == ifselected - 8*i)) {
                                    for(j = 1;j <= i ;j++) {
                                    	if((granary[ifselected - 8*j] != -1)){
                                        if(myChess[granary[ifselected - 8*j]].type*isPlayerA > 0) {
                                            flag = -1;
                                            console.log("车所在横-位置期间有己方，buuuuuuuu允许落子");
                                            document.getElementById("info").innerHTML="Vous êtes tour, vous ne pouvez pas se mettre ici";
                                        }
                                    }
                                    }
                                    if(flag == -1) {
                                        canP = false;
                                    } else {
                                        canP = true;
                                    }
                                    break;
                                }

                                else if((circleNum == ifselected + i)&& (checkLine == 0)) {
                                    for(j = 1;j <= i ;j++) {
                                    	if((granary[ifselected + j] != -1)){
                                        if(myChess[granary[ifselected + j]].type*isPlayerA > 0) {
                                            flag = -1;
                                            console.log("车所在竖+位置期间有己方，buuuuuuuu允许落子");
                                            document.getElementById("info").innerHTML="Vous êtes tour, vous ne pouvez pas se mettre ici";
                                        }
                                    }
                                    }
                                    if(flag == -1) {
                                        canP = false;
                                    } else {
                                        canP = true;
                                    }
                                    break;
                                } 
                                else if((circleNum == ifselected - i)&& (checkLine == 0)) {
                                    for(j = 1;j <= i ;j++) {
                                    	if((granary[ifselected - j] != -1)){
                                        if(myChess[granary[ifselected - j]].type*isPlayerA > 0) {
                                            flag = -1;
                                            console.log("车所在竖-位置期间有己方，buuuuuuuu允许落子");
                                            document.getElementById("info").innerHTML="Vous êtes tour, vous ne pouvez pas se mettre ici";
                                        }
                                    }
                                    }
                                    if(flag == -1) {
                                        canP = false;
                                    } else {
                                        canP = true;
                                    }
                                    break;
                                }
                                else {
                                    canP = false;
                                }
                        }            
                    break;
                    case 5*isPlayerA:
                    //Queen(皇后):可横走、直走或斜走，移动步数不限，但不可转向或越过其他棋子。可以说是车与象的结合
                    var i = 0, j = 0;
                    var flag = 0;
                        for(i = 1;i < 8 ;i++) {
                                if((circleNum == ifselected + 8*i)) {
                                    for(j = 1;j <= i ;j++) {
                                    	if((granary[ifselected + 8*j] != -1)){
                                        if(myChess[granary[ifselected + 8*j]].type*isPlayerA > 0) {
                                            flag = -1;
                                            console.log("皇后所在横+方向期间有己方，buuuuuuuu允许落子");
                                            document.getElementById("info").innerHTML="Vous êtes dame, vous ne pouvez pas se mettre ici";
                                        }
                                    }
                                    }
                                    if(flag == -1) {
                                        canP = false;
                                    } else {
                                        canP = true;
                                    };
                                    break;
                                } 
                                else if((circleNum == ifselected - 8*i)) {
                                    for(j = 1;j <= i ;j++) {
                                    	if((granary[ifselected - 8*j] != -1)){
                                        if(myChess[granary[ifselected - 8*j]].type*isPlayerA > 0) {
                                            flag = -1;
                                            console.log("皇后所在横-方向期间有己方，buuuuuuuu允许落子");
                                            document.getElementById("info").innerHTML="Vous êtes dame, vous ne pouvez pas se mettre ici";
                                        }
                                    }
                                    }
                                    if(flag == -1) {
                                        canP = false;
                                    } else {
                                        canP = true;
                                    }
                                    break;
                                }

                                else if((circleNum == ifselected + i)&& (checkLine == 0)) {
                                    for(j = 1;j <= i ;j++) {
                                    	if((granary[ifselected + j] != -1)){
                                        if(myChess[granary[ifselected + j]].type*isPlayerA > 0) {
                                            flag = -1;
                                            console.log("皇后所在竖+方向期间有己方，buuuuuuuu允许落子");
                                            document.getElementById("info").innerHTML="Vous êtes dame, vous ne pouvez pas se mettre ici";
                                        }
                                    }
                                    }
                                    if(flag == -1) {
                                        canP = false;
                                    } else {
                                        canP = true;
                                    }
                                    break;
                                } 
                                else if((circleNum == ifselected - i)&& (checkLine == 0)) {
                                    for(j = 1;j <= i ;j++) {
                                    	if((granary[ifselected - j] != -1)){
                                        if(myChess[granary[ifselected - j]].type*isPlayerA > 0) {
                                            flag = -1;
                                            console.log("皇后所在竖-方向期间有己方，buuuuuuuu允许落子");
                                            document.getElementById("info").innerHTML="Vous êtes dame, vous ne pouvez pas se mettre ici";
                                        }
                                    }
                                    }
                                    if(flag == -1) {
                                        canP = false;
                                    } else {
                                        canP = true;
                                    }
                                    break;
                                }
                                
                                //下面是象的规则 套用到此处
                                else if((circleNum == ifselected + 9*i)&& (checkLine == i)) {
                                    for(j = 1;j <= i ;j++) {
                                    	if((granary[ifselected + 9*j] != -1)){
                                        if(myChess[granary[ifselected + 9*j]].type*isPlayerA > 0) {
                                            flag = -1;
                                            console.log("皇后所在斜+方向期间有己方，buuuuuuuu允许落子");
                                            document.getElementById("info").innerHTML="Vous êtes dame, vous ne pouvez pas se mettre ici";
                                        }
                                    }
                                    }
                                    if(flag == -1) {
                                        canP = false;
                                    } else {
                                        canP = true;
                                    }
                                    break;
                                } 
                                else if((circleNum == ifselected - 9*i)&& (checkLine == i)) {
                                    for(j = 1;j <= i ;j++) {
                                    	if((granary[ifselected - 9*j] != -1)){
                                        if(myChess[granary[ifselected - 9*j]].type*isPlayerA > 0) {
                                            flag = -1;
                                             console.log("皇后所在斜-方向期间有己方，buuuuuuuu允许落子");
                                             document.getElementById("info").innerHTML="Vous êtes dame, vous ne pouvez pas se mettre ici";
                                        }
                                    }
                                    }
                                if(flag == -1) {
                                        canP = false;
                                    } else {
                                        canP = true;
                                    }
                                break;
                                }
                        
                                else if((circleNum == ifselected + 7*i)&& (checkLine == i)) {
                                    for(j = 1;j <= i ;j++) {
                                    	if((granary[ifselected + 7*j] != -1)){
                                        if(myChess[granary[ifselected + 7*j]].type*isPlayerA > 0) {
                                            flag = -1;
                                            console.log("皇后所在斜+方向期间有己方，buuuuuuuu允许落子");
                                            document.getElementById("info").innerHTML="Vous êtes dame, vous ne pouvez pas se mettre ici";
                                        }
                                    }
                                    }
                                    if(flag == -1) {
                                        canP = false;
                                    } else {
                                        canP = true;
                                    }
                                    break;
                                } 
                                else if((circleNum == ifselected - 7*i)&& (checkLine == i)) {
                                    for(j = 1;j <= i ;j++) {
                                    	if((granary[ifselected -7*j] != -1)){
                                        if(myChess[granary[ifselected - 7*j]].type*isPlayerA > 0) {
                                            flag = -1;
                                            console.log("皇后所在斜-方向期间有己方，buuuuuuuu允许落子");
                                            document.getElementById("info").innerHTML="Vous êtes dame, vous ne pouvez pas se mettre ici";
                                        }
                                    }
                                    }
                                    if(flag == -1) {
                                        canP = false;
                                    } else {
                                        canP = true;
                                    }
                                    break;
                                }
                                else {
                                    canP = false;
                                } 
                        }            
                        break;
                        //王
                        case 6*isPlayerA:
                        if(((granary[circleNum]!= -1) && (myChess[granary[circleNum]].type*isPlayerA < 0 ))|| granary[circleNum]==-1){
                            if((circleNum == ifselected-1) || (circleNum == ifselected+1)) {
                                if(checkLine == 0){
                                    canP = true;
                                    console.log("王所选位置有敌人或空，允许落子");
                                    document.getElementById("info").innerHTML="Vous êtes roi, vous pouvez se mettre ici";
                                }
                                else{
                                    canP = false;
                                    console.log("王所选位置有敌人或空，buuuuuuuu允许落子");
                                    document.getElementById("info").innerHTML="Vous êtes roi, vous ne pouvez pas se mettre ici";
                                }
                            }
                            if((circleNum == ifselected-8) 
                            || (circleNum == ifselected+8) 
                            || (circleNum == ifselected-7) 
                            || (circleNum == ifselected-9) 
                            || (circleNum == ifselected+7) 
                            || (circleNum == ifselected+9)){
                                if(checkLine == 1){
                                    canP = true;
                                    console.log("王所选位置有敌人或空，允许落子");
                                    document.getElementById("info").innerHTML="Vous êtes roi, vous pouvez se mettre ici";
                                }
                                else{
                                    canP = false;
                                    console.log("王所选位置有敌人或空，buuuuuuuu允许落子");
                                    document.getElementById("info").innerHTML="Vous êtes roi, vous ne pouvez pas se mettre ici";
                                }
                            }
                            else{
                                canP = false;
                                console.log("王所选位置有敌人或空，buuuuuuuu允许落子");
                                document.getElementById("info").innerHTML="Vous êtes roi, vous ne pouvez pas se mettre ici";
                            }
                        }
                        else{
                            canP = false;
                            console.log("王所选位置有自己人，buuuuuuuu允许落子");
                            document.getElementById("info").innerHTML="Vous êtes roi, vous ne pouvez pas se mettre ici";
                        }
                        break;
                        default:
                        break;
                    }
                
                }


                if(num == 4){
                    if(granary[circleNum]== -1){
                        console.log("这里没有棋子，不可以选择");
                        document.getElementById("info").innerHTML="Ici vous ne pouvez pas choisir une pièce";
                    }
                    else{
                        ifselected = circleNum;
                        myChess[33].positionx = myChess[granary[circleNum]].positionx;
                        myChess[33].positiony = myChess[granary[circleNum]].positiony;
                        console.log("现在"+currentPlayer+"选择了一个",whichChess(myChess[granary[circleNum]].type));
                        document.getElementById("info").innerHTML=" Vous êtes " + currentPlayer;
                    }
                }
                

                //console.log("Place has been selected.");
                
                //console.log("CircleNum"+ circleNum +" selected");
                self.emit("circleNumber",1);

                if(num == 5){
                    console.log(granary);
                    if(ifselected != -1){
                    if(canP ){
                        //若下棋所在位置有A方的王,B赢了
                        if(granary[circleNum]!=-1){
                        if(myChess[granary[circleNum]].type==6 && currentPlayer == 'B'){
                            resultB = 1;
                        }
                        else if(myChess[granary[circleNum]].type==-6 && currentPlayer == 'A'){
                            resultA = 1;
                        }
                    }
                        
                        //circlenum =  要放置的位置
                        //ifselete = 选择的棋子的位置
                        var targety = circleNum %8;
                        var targetx = parseInt(circleNum/8);

                        if(granary[circleNum] != -1) {
                           myChess[granary[circleNum]].type = 0;
                           sphere[granary[circleNum]].position.x=0;
                           sphere[granary[circleNum]].position.y=0;
                           sphere[granary[circleNum]].position.z=0;
                        }

                        myChess[granary[ifselected]].positionx = targetx;
                        myChess[granary[ifselected]].positiony = targety;
                        myChess[33].positionx = targetx;
                        myChess[33].positiony = targety;

                        

                        granary[circleNum] = granary[ifselected];
                        granary[ifselected] = -1;
                        console.log("当前玩家"+ currentPlayer+"下子成功!");
                        document.getElementById("info").innerHTML= "Vous êtes " + currentPlayer + ", vous avez fini ce retour";
                        
                        
                        
                        if(currentPlayer == 'A'){
                            currentPlayer = 'B';
                            isPlayerA = -1;
                            circleNum = 56;
                            myChess[33].positionx =  ((circleNum+1)-(circleNum+1)%8)/8;
                            myChess[33].positiony = (circleNum+1)%8 -1;
                            myChess[32].positionx =  ((circleNum+1)-(circleNum+1)%8)/8;
                            myChess[32].positiony = (circleNum+1)%8 -1;
                        }
                        else{
                            currentPlayer = 'A';
                            isPlayerA = 1;
                            circleNum = 0;
                            myChess[33].positionx = 0;
                            myChess[33].positiony = 0;
                            myChess[32].positionx = 0;
                            myChess[32].positiony = 0;
                        }
                        canP = false;           
                    }
                    else{
                        console.log("这个位置"+circleNum+"不能落子，请重新选择");
                        document.getElementById("info").innerHTML="Vous ne pouvez pas mettre une pièce ici, veuillez choisir une autre fois";
                        circleNum = ifselected;            
                    }
                    ifselected = -1;
                }
                else{
                    console.log("请先选择棋子");
                    document.getElementById("info").innerHTML="Veuillez choisir une autre fois";
                }
                }
                
                
                

                return;
    }

            

            //game over situation
            this.gameOver=function(){
                if (resultA == 1){
                    console.log("player A wins");
                    return true;
                }
                else if(resultB == 1){
                    console.log("player B wins");
                    return true;
                }
                else 
                    return false;
            }

            var end=function(){
                if(resultA == 1){
                    document.getElementById("info").innerHTML="the winner is A";
                }
                else if(resultB == 1){
                    document.getElementById("info").innerHTML="the winner is B";
                }
                /*
                else{
                    document.getElementById("info").innerHTML="A has won :"+resultA+" B has won :"+resultB ;
                }
                */
                
            }



            this.setId=function(i){
                id=i;
            }

            this.select=function(event){
                var key=event.keyCode;
                //console.log("in select "+ key);

                //字母w为上
                    if(key==87){
                        self.emit("onKeyDown",0);
                    }
                //字母s为下    
                    if(key==83){
                        self.emit("onKeyDown",1);
                    }
                //字母a为左
                    if(key==65){
                        self.emit("onKeyDown",2);
                    }
                //字母d为右
                    if(key==68){
                        self.emit("onKeyDown",3);
                    }
                //o键为选定棋子
                    if(key==79){
                        self.emit("onKeyDown",4);
                    }
                //p键为落子    
                    if(key==80){
                             self.emit("onKeyDown",5);
                    }

                }

               
            document.addEventListener("keydown",this.select);
            document.addEventListener("keypress",end);
        },
        ['init','setCircle', 'update', 'gameOver',"setId","setObject1","setObject2","setSelect","setCircle","select","setSphere"],
        ['newObject1','newObject2','newCircle','newSelect','onKeyDown','object1Set','object2Set','circleSet','selectSet','circleSelected','circleNumber']
        );

return { Chess : Chess };
},
[ "deps/three.js/index" ]
);

