arcs_module(
    function(ARCS, three, _objloader, _mtlloader, _objmtlloader) {
        var OBJLoader;

        
        OBJLoader = ARCS.Component.create(
            function() {
                var self = this;
                var innerObject; 
                
                var onLoadWrapper = function(obj) {
                    innerObject = obj;
                    console.log("[OBJLoader/chess] object has %d components", obj.children.length); 
                    self.emit("onLoad", obj);
                };

                var onLoadWrapperObject1 = function(obj) {
                    innerObject = obj;
                    console.log("Object1");
                    console.log("[OBJLoader/Object1] object has %d components", obj.children.length); 
                    self.emit("onLoadObject1", obj);
                };

                var onLoadWrapperObject2 = function(obj) {
                    innerObject = obj;
                    console.log("Object2");
                    console.log("[OBJLoader/Object2] object has %d components", obj.children.length); 
                    self.emit("onLoadObject2", obj);
                };

                var onLoadWrapperCircle = function(obj) {
                    innerObject = obj;
                    console.log("Circle");
                    console.log("[OBJLoader/Circle] object has %d components", obj.children.length); 
                    self.emit("onLoadCircle", obj);
                };
                
                var onLoadWrapperSelect = function(obj) {
                    innerObject = obj;
                    console.log("Select");
                    console.log("[OBJLoader/Circle] object has %d components", obj.children.length); 
                    self.emit("onLoadSelect", obj);
                };

                var onLoadJSON = function(geom, mat) {
                    innerObject = new THREE.Mesh(geom, new THREE.MeshFaceMaterial(mat));
                    
                    self.emit("onLoad", innerObject);
                };
                
                var progress = function ( xhr ) { 
                    console.log( (xhr.loaded / xhr.total * 100) + '% loaded' ); 
                };
                
                var error = function ( xhr ) { 
                    console.log( 'An error happened' ); 
                };
                
                this.load = function(obj1URL, mtl1URL, obj2URL, mtl2URL, obj2, mtl2, circle,circleMtl, select, selectMtl) {
                    var loader;
                    // we may use a string tokenizer to determine file types 
                    // then all would be in the same loading slot.
                    
                    
                    console.log("loading objects", obj1URL, mtl1URL);
                    console.log("loading objects", obj2URL, mtl2URL);
                    /*if (mtl1URL === undefined) {
                        //console.log("using loader");
                        loader = new THREE.OBJLoader();
                        loader.load(obj1URL, onLoadWrapper, progress, error);                        
                    }else {
                        //console.log("using mtl loader");
                        loader = new THREE.OBJMTLLoader();
                        if(obj1URL=="chessboard.obj"){
                            loader.load(obj1URL, mtl1URL, onLoadWrapper, progress, error);                        
                        }
                        if(obj2=="chessboard.obj"){
                            loader.load(obj2, mtl2, onLoadWrapper, progress, error);                        
                        }
                        else{
                            loader.load(obj2,mtl2,onLoadWrapperWhite,progress,error);
                        }
                    }*/
                    loader = new THREE.OBJMTLLoader();
                    if(obj1URL === "chessboard.obj"){
                        loader.load(obj2, mtl2, onLoadWrapperObject1, progress, error);
                        loader.load(obj2URL, mtl2URL, onLoadWrapperObject2, progress, error);
                        loader.load(obj1URL, mtl1URL, onLoadWrapper, progress, error);
                        loader.load(select, selectMtl, onLoadWrapperSelect, progress, error);
                        loader.load(circle, circleMtl, onLoadWrapperCircle, progress, error);
                        console.log("1shabiiiiii");
                    }else if(obj2URL === "chessboard.obj"){
                        loader.load(obj2, mtl2, onLoadWrapperObject1, progress, error);
                        loader.load(obj1URL, mtl1URL, onLoadWrapperObject2, progress, error);
                        loader.load(obj2URL, mtl2URL, onLoadWrapper, progress, error);
                        loader.load(select, selectMtl, onLoadWrapperSelect, progress, error);
                        loader.load(circle, circleMtl, onLoadWrapperCircle, progress, error);
                        console.log("2shabiiiiii");
                    }else if(obj2 === "chessboard.obj"){
                        loader.load(obj1URL, mtl1URL, onLoadWrapperObject1, progress, error);
                        loader.load(obj2URL, mtl2URL, onLoadWrapperObject2, progress, error);
                        loader.load(obj2, mtl2, onLoadWrapper, progress, error);
                        loader.load(select, selectMtl, onLoadWrapperSelect, progress, error);
                        loader.load(circle, circleMtl, onLoadWrapperCircle, progress, error);
                        console.log("3shabiiiiii");
                    }
                    /*loader = new THREE.OBJMTLLoader();
                    loader.load(obj1URL, mtl1URL, onLoadWrapperWhite, progress, error);
                    loader.load(obj2URL, mtl2URL, onLoadWrapperBlack, progress, error);
                    loader.load(obj2, mtl2, onLoadWrapper, progress, error);*/
                
                }; 
                
                this.loadJSON = function(jsonURL) {
                    var loader;
                    //console.log("loading objects", jsonURL);
                    loader = new THREE.JSONLoader();
                    loader.load(jsonURL, onLoadJSON); //, progress, error);                         
                    
                    
                };
                
                var MAX3 = function (a,b,c) {
                    if ( a >= b ) {
                       if ( a >= c) {
                           return a;
                       } else {
                           return c;
                       }
                   } else {
                       if (b >= c) {
                           return b;
                       } else {
                           return c;
                       }
                   }
               };

               this.unitize = function() {
                if (innerObject === undefined) { return ; }
                var box = new THREE.Box3(); 
                box.setFromObject(innerObject);
                var s = box.size();
                var c = box.center();
                var scale = 1 / MAX3(s.x, s.y, s.z);                    
                innerObject.scale.x = innerObject.scale.y = innerObject.scale.z = scale;
            };

            this.resize = function(s) {
                this.unitize();
                if (innerObject === undefined) { return ; }
                innerObject.scale.x *= s;
                innerObject.scale.y *= s;
                innerObject.scale.z *= s;
            };

        },
        ["load","unitize", "resize"],
        ["onLoad","onLoadObject1", "onLoadObject2", "onLoadSelect", "onLoadCircle"]
        );
        
        return { OBJLoader: OBJLoader}; 
    },
    [ 'deps/three.js/index', 'deps/objloader/index', 'deps/mtlloader/index','deps/objmtlloader/index' ]
    );